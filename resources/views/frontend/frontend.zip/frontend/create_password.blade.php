@include('frontend.include.header')
@include('frontend.include.nav-bar')
    <!-- header area end -->


    <!-- popup search -->
    <div class="search-popup">
        <button class="close-search"><span class="far fa-times"></span></button>
        <form action="#">
            <div class="form-group">
                <input type="search" name="search-field" class="form-control" placeholder="Search Here..." required>
                <button type="submit"><i class="far fa-search"></i></button>
            </div>
        </form>
    </div>
    <!-- popup search end -->


    


    <main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb" style="background: url({{ asset('public/assets/img/breadcrumb/01.jpg') }})">
            <div class="container">
                <h2 class="breadcrumb-title">Change Password</h2>
                <ul class="breadcrumb-menu">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active">Change Password</li>
                </ul>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- login area -->
        <div class="auth-area py-80">
            <div class="container">
                <div class="col-md-5 mx-auto">
                    <div class="auth-form">
                        <div class="auth-header">
                          
                            
                                               @if ($errors->has('error'))
    <div class="alert alert-danger">
        {{ $errors->first('error') }}
    </div>
@endif
@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif
@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
                        </div>
     


                        <form action="{{ url('/set-password') }}" method="POST">
                            @csrf
                            <input type="hidden" name="email" value="{{ Session::get('otp_email') }}">
                            <div class="form-group">
                                <div class="form-icon">
                                    <input type="password" name="password" class="form-control" value="{{ old('password') }}" placeholder="New Password" required>
                                </div>
                                
                            </div>
                             <div class="form-group">
                                <div class="form-icon">
                                    <input type="password" name="password_confirmation" class="form-control" value="{{ old('password_confirmation') }}" placeholder="Confirm Password" required>
                                </div>
                                
                            </div>
                   
                            <div class="auth-btn">
                                <button type="submit" class="theme-btn"><span class="far fa-sign-in"></span> Save </button>
                            </div>
                        </form>
                        <div class="auth-bottom">
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- login area end -->

    </main>

<!-- footer area -->
@include('frontend.include.footer')
</body>


</html>