@include('frontend.include.header')
@include('frontend.include.nav-bar')
    <!-- header area end -->


    <!-- popup search -->
    <div class="search-popup">
        <button class="close-search"><span class="far fa-times"></span></button>
        <form action="#">
            <div class="form-group">
                <input type="search" name="search-field" class="form-control" placeholder="Search Here..." required>
                <button type="submit"><i class="far fa-search"></i></button>
            </div>
        </form>
    </div>
    <!-- popup search end -->

    <main class="main">

        <!-- breadcrumb -->
        <!--<div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">-->
        <!--    <div class="container">-->
        <!--        <h2 class="breadcrumb-title">Profile</h2>-->
        <!--        <ul class="breadcrumb-menu">-->
        <!--            <li><a href="index.html">Home</a></li>-->
        <!--            <li class="active">Profile</li>-->
        <!--        </ul>-->
        <!--    </div>-->
        <!--</div>-->
        <!-- breadcrumb end -->

        
        <!-- dashboard area -->
        <div class="dashboard-section pt-5 mb-110">
        <div class="container">
         <div class="row">
             
           <div class="profile-nav col-md-3">
         
      
      @include('frontend.include.user-sidebar')
      
  </div>
 
  <div class="profile-info col-md-9">
   
      <div>
          <div class="row">
              @if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
   @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
              <div class="col-md-12 mb-3">
                  <h4>Profile</h4>
                   <hr/>
                 
              </div>
              <div class="col-md-12 mb-3">
                        <form action="{{ url('user/update-profile') }}" method="POST">
                            @csrf
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label>Full Name</label> <input class="form-control" name="full_name" placeholder="Full Name" type="text" value="{{ Auth::user()->full_name ?? '' }}">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>Email</label> <input class="form-control" name="email" placeholder="Email" type="text" value="{{ Auth::user()->email ?? '' }}" readonly >
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>Phone</label> <input class="form-control" name="mobile_number" placeholder="Phone" type="text" value="{{ Auth::user()->mobile_number ?? '' }}">
														</div>
													</div>
													<div class="col-md-12">
														<div class="form-group">
															<label>Address</label> <input class="form-control" name="address"  placeholder="Address" type="text" value="{{ Auth::user()->address ?? '' }}">
														</div>
													</div>
													<div class="col-md-12 mb-3 d-flex" style="justify-content: space-between;">
                  <h4>Company Information</h4>
              </div>
                                                    <div class="col-md-12 field-group">
														<div class="form-group">
															<label class="editable-label" contenteditable="false">Company Name</label> <input class="form-control" name="company_name"  placeholder="Company Name" type="text" value="{{ Auth::user()->company_name ?? '' }}">
														</div>
													</div>
												<div class="col-md-4">
														<div class="form-group">
															<label>ABN</label> <input class="form-control" name="abn"  placeholder="ABN" type="text" value="{{ Auth::user()->abn ?? '' }}">
														</div> 
													</div>
														<div class="col-md-4">
														<div class="form-group">
															<label>Suburb</label> 
														<input class="form-control" placeholder="Suburb" name="suburb" type="text" value="{{ Auth::user()->suburb ?? '' }}">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group">
															<label>State</label> 
														<input class="form-control" placeholder="State" name="state" type="text" value="{{ Auth::user()->state ?? '' }}">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group">
															<label>Postcode</label> 
														<input class="form-control" placeholder="Postcode" name="postcode" type="text" value="{{ Auth::user()->postcode ?? '' }}">
														</div>
													</div>
              
												</div><button class="theme-btn my-3" type="submit"> Save Changes</button>
											</form>

    </div>
    
             <div class="col-md-12 mb-3 d-flex" style="justify-content: space-between;">
                  <h4>Password Setting</h4>
              </div>
              
              <div class="col-md-12">
                  <form action="{{ url('user/change-password') }}" method="POST"  >
                      @csrf
													<div class="form-group">
														<label>Old Password</label> <input class="form-control" name="old_password" placeholder="Old Password" type="password">
													</div>
													<div class="form-group">
														<label>New Password</label> <input class="form-control" name="new_password" placeholder="New Password" type="password">
													</div>
													<div class="form-group">
														<label>Re-Type Password</label> <input class="form-control" name="new_password_confirmation"  placeholder="Re-Type Password" type="password">
													</div><button class="theme-btn my-3" type="submit">Change Password</button>
												</form>
              </div>
            </div>
           </div>
          </div>  
              
         </div>
         <!--end row -->
     </div>
    </div>
        <!-- end dashboard area -->


        

    </main>

<!-- footer area -->
@include('frontend.include.footer')
</body>


</html>