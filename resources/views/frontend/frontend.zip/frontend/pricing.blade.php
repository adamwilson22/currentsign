@include('frontend.include.header')

   <section class="w-100 sec_pad">
           <div class="container ptb-100">
                    <div class="pricing-content">
                        <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="table-list wow fadeInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                                <div class="top-price-inner">
                                    <h4>Basic</h4>
                                    <div class="rates">
                                        <span class="prices"><span class="dolar">$</span>15</span><span class="users">Per Month</span>
                                    </div>
                                </div>
                                <ol>
                                    <li class="check">Online System</li>
                                    <li class="check">Free Lorem ipsum d</li>
                                    <li class="check">full access</li>
                                    <li class="check">live preview</li>
                                    <li class="check">Support unlimited</li>
                                </ol>
                                <div class="">
                                    <a href="#" class="btn btn-primary">Upgrade now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="table-list wow fadeInUp" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
                                <div class="top-price-inner">
                                    <h4>Standard</h4>
                                    <div class="rates">
                                        <span class="prices"><span class="dolar">$</span>80</span><span class="users">Per Month</span>
                                    </div>
                                </div>
                                <ol>
                                    <li class="check">Online System</li>
                                    <li class="check">Free Lorem ipsum d</li>
                                    <li class="check">full access</li>
                                    <li class="check">live preview</li>
                                    <li class="check">Support unlimited</li>
                                </ol>
                                <div class="">
                                    <a href="#" class="btn btn-primary">Upgrade now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="table-list wow fadeInUp" data-wow-delay="0.7s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">
                                <div class="top-price-inner">
                                    <h4>Premium</h4>
                                    <div class="rates">
                                        <span class="prices"><span class="dolar">$</span>99</span><span class="users">Per Month</span>
                                    </div>
                                </div>
                                <ol>
                                   <li class="check">Online System</li>
                                    <li class="check">Free Lorem ipsum d</li>
                                    <li class="check cross">full access</li>
                                    <li class="check">live preview</li>
                                    <li class="check">Support unlimited</li>
                                </ol>
                                <div class="">
                                    <a href="#" class="btn btn-primary">Upgrade now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
        </section>


@include('frontend.include.footer')
</body>


</html>