
<!doctype html>
<html lang="en">



<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="https://jbservicesus.com/current-sign/img/favicon.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/assets/bootstrap/css/bootstrap.min.css">
    <!-- icon css-->
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/assets/elagent-icon/style.css">
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/assets/animation/animate.css">
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/css/style.css">
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/css/responsive.css">
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/assets/slick/slick.css">
    <link rel="stylesheet" href="https://jbservicesus.com/current-sign/assets/slick/slick-theme.css">
    <title>Current Sign</title>
</head>

<body data-scroll-animation="true">
<div id="preloader">
    <div id="ctn-preloader" class="ctn-preloader">
        <div class="round_spinner">
            <div class="spinner"></div>
            <div class="text">
                <img src="https://jbservicesus.com/current-sign/img/logo.png" alt="" style="width:100px">
             
            </div>
        </div>
       
    </div>
</div>
<div class="body_wrapper">
    <nav class="navbar navbar-expand-lg menu_two" id="sticky">
        <div class="container">
            <a class="navbar-brand" href="index.html">
                <img src="https://jbservicesus.com/current-sign/img/logo.png"  alt="logo" style="width:100px">
            </a>
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="menu_toggle">
                        <span class="hamburger">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                        <span class="hamburger-cross">
                            <span></span>
                            <span></span>
                        </span>
                    </span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav menu dk_menu ml-auto">
                  
                    <li class="nav-item">
                        <a href="{{ url('/') }}" class="nav-link">Home</a>
                    </li>
                     <li class="nav-item">
                        <a href="#" class="nav-link">About Us</a>
                    </li>

                     <li class="nav-item">
                        <a href="{{ url('/pricing') }}" class="nav-link">Pricing Plan</a>
                    </li>
                     <li class="nav-item">
                        <a href="#" class="nav-link">Contact Us</a>
                    </li>
                
                </ul>
                 <a class="nav_btn btn btn-primary" href="#">Free Trial</a>
                <a class="nav_btn btn btn-primary ml-2" href="{{ url('/login') }}"><i class="icon_profile"></i>Log In</a>
            </div>
        </div>
    </nav>