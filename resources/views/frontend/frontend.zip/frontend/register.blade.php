@include('frontend.include.header')

  <div class="body_wrapper">
        <section class="signup_area signup_area_height">
            <div class="row ml-0 mr-0">
               
                <div class="sign_right signup_right">
                    <div class="sign_inner signup_inner">
                        <div class="text-center">
                            <h3>Create your Account</h3>
                            <p>Already have an account? <a href="signin.html">Sign in</a></p>
                            <a href="#" class="btn-google"><img src="img/signup/gmail.png" alt=""><span class="btn-text">Sign up with Google</span></a>
                        </div>
                        <div class="divider">
                            <span class="or-text">or</span>
                        </div>
                        <form action="#" class="row login_form">
                            <div class="col-sm-6 form-group">
                                <div class="small_text">First name</div>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Muhammad">
                            </div>
                            <div class="col-sm-6 form-group">
                                <div class="small_text">Last name</div>
                                <input type="text" class="form-control" name="lname" id="lname" placeholder="Jewel">
                            </div>
                            <div class="col-lg-12 form-group">
                                <div class="small_text">Your email</div>
                                <input type="email" class="form-control" id="email" placeholder="info@KbDoc.com">
                            </div>
                            <div class="col-lg-12 form-group">
                                <div class="small_text">Password</div>
                                <input id="signup-password" name="signup-password" type="password" class="form-control" placeholder="Password " autocomplete="off">
                            </div>
                            <div class="col-lg-12 form-group">
                                <div class="small_text">Confirm password</div>
                                <input id="confirm-password" name="confirm-password" type="password" class="form-control" placeholder="Confirm password required" autocomplete="off">
                            </div>
                            <div class="col-lg-12 form-group">
                                <div class="check_box">
                                    <input type="checkbox" value="None" id="squared2" name="check">
                                    <label class="l_text" for="squared2">I accept the <span>politic of confidentiality</span></label>
                                </div>
                            </div>
                            <div class="col-lg-12 text-center">
                                <button type="submit" class="btn action_btn thm_btn">Create an account</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>


<!-- footer area -->
@include('frontend.include.footer')
</body>


</html>