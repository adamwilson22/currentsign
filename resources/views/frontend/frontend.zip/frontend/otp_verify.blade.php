@include('frontend.include.header')
@include('frontend.include.nav-bar')
    <!-- header area end -->


    <!-- popup search -->
    <div class="search-popup">
        <button class="close-search"><span class="far fa-times"></span></button>
        <form action="#">
            <div class="form-group">
                <input type="search" name="search-field" class="form-control" placeholder="Search Here..." required>
                <button type="submit"><i class="far fa-search"></i></button>
            </div>
        </form>
    </div>
    <!-- popup search end -->


    


    <main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb" style="background: url({{ asset('public/assets/img/breadcrumb/01.jpg') }})">
            <div class="container">
                <h2 class="breadcrumb-title">Verify</h2>
                <ul class="breadcrumb-menu">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active">Verify</li>
                </ul>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- login area -->
        <div class="auth-area py-80">
            <div class="container">
                <div class="col-md-5 mx-auto">
                    <div class="auth-form">
                        <div class="auth-header">
                          
                            
                                               @if ($errors->has('error'))
    <div class="alert alert-danger">
        {{ $errors->first('error') }}
    </div>
@endif
@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif
@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
                        </div>
     


                        <form action="{{ url('/verify-otp') }}" method="POST">
                            @csrf
                            <input type="hidden" name="email" value="{{ request('email') }}">

                            <div class="form-group">
                                <div class="form-icon">
                                    <input type="number" name="otp" class="form-control" value="{{ old('otp') }}" placeholder="Enter  otp" required>
                                </div>
                                
                            </div>
                   
                            <div class="auth-btn">
                                <button type="submit" class="theme-btn"><span class="far fa-sign-in"></span> Verify </button>
                            </div>
                        </form>
                        <div class="auth-bottom">
                            <!--<div class="auth-social">-->
                            <!--    <p>Continue with social media</p>-->
                            <!--    <div class="auth-social-list">-->
                            <!--        <a href="#"><i class="fab fa-facebook-f"></i></a>-->
                            <!--        <a href="#"><i class="fab fa-google"></i></a>-->
                            <!--        <a href="#"><i class="fab fa-x-twitter"></i></a>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- login area end -->

    </main>

<!-- footer area -->
@include('frontend.include.footer')
</body>


</html>